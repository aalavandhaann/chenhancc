.. automodule:: python_example
